#!/usr/bin/env python

from distutils.core import setup

name = 'pysopra'
setup(name=name,
        version='0.0.4',
        description='Python interface to the SOPRA database',
        author='Paul Anton Letnes',
        author_email='paul.anton.letnes@gmail.com',
        url='http://www.nohomepageyet.com',
        license='GPLv2',
        packages=[name, ],
        package_data={name: ['SOPRADatabase/*']},
        scripts=['bin/plotSOPRA', ]
    )
						




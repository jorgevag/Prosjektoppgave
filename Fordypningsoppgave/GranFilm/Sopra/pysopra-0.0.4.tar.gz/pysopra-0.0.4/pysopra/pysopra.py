#! /usr/bin/env python
"""
A python module that lets you calculate the dielectric function of certain
materials by various means.
"""
# Python packages
import os
import sys
# Scientific packages
import numpy
from scipy.interpolate import UnivariateSpline
# The package itself
import pysopra

SOPRA_ROOT = 'SOPRADatabase'
FILE_SUFFIX = '.nk'
# Flags for micrometer, eV
FLAG_EV = 1
FLAG_MICRON = 2
# Physical constants
HC = 2 * numpy.pi * 0.1973269631 # [um eV]

def micron2eV(micron):
    """Convert a wavelength in micron to the corresponding photon energy."""
    return HC / micron

def eV2micron(eV):
    """Convert a wavelength in micron to the corresponding photon energy."""
    return HC / eV

def parseSOPRAfile(datafile):
    """Parse the header of the data file."""
    header = datafile.readline().split()
    flag = int(header[0])
    fmin, fmax = float(header[1]), float(header[2])
    nk = numpy.loadtxt(datafile)
    npoints = nk.shape[0]
    if flag == FLAG_MICRON:
        #msg = 'The database does not use micron, hence it is unsupported.'
        #print >> sys.stderr, msg
        #raise ValueError('Micron not supported!')

        # This is how it _should_ work:
        # We must convert um to eV
        fmax, fmin = micron2eV(fmin), micron2eV(fmax)
        # ... and reverse the order of n and k.
        nk = nk[::-1, :]
    frequencies = numpy.linspace(fmin, fmax, npoints)
    #print 'SOPRA frequency range: %.2f, %.2f, material: %s' % (frequencies[0], frequencies[-1], str(datafile))
    return frequencies, nk[:, 0] + 1.0j * nk[:, 1]

class AbstractEpsilon(object):
    """Superclass of all the Epsilon classes."""
    def getfrequency(self, frequencyOrWavelength, micron):
        """Convert argument of getepsilon to frequency [rad^{-1}]."""
        if micron:
            # Frequency is really the wavelength
            frequency = micron2eV(frequencyOrWavelength)
        else:
            frequency = frequencyOrWavelength
        return frequency

class EpsilonSOPRA(AbstractEpsilon):
    """
    The EpsilonSOPRA class lets the user calculate the interpolated
    dielectric function of a given material for a range of frequencies.
    Data are collected from the SOPRA database and interpolated using
    a cubic spline from scipy.interpolate.
    """
    def __init__(self, material):
        super(EpsilonSOPRA, self).__init__()
        self.material = material
        moduledir = os.path.dirname(pysopra.__file__)
        parts = [moduledir, SOPRA_ROOT, material + FILE_SUFFIX]
        datafilepath = os.path.join(*parts)
        try:
            datafile = open(datafilepath)
        except IOError as err:
            msg = 'pySOPRA error - Unrecognized material: "%s"' % self.material
            print >> sys.stderr, msg
            raise err
        frequencies, nk = parseSOPRAfile(datafile)
        self.minfreq = frequencies[0]
        self.maxfreq = frequencies[-1]
        self.real_inter = UnivariateSpline(frequencies, nk.real, s=0)
        self.imag_inter = UnivariateSpline(frequencies, nk.imag, s=0)

    def getepsilon(self, frequencyOrWavelength, micron=False):
        frequency = self.getfrequency(frequencyOrWavelength, micron)
        errmsg = 'Error: Frequency outside data range! (min, max, freq.) = '
        errmsg += ', '.join(map(str, (self.minfreq, self.maxfreq, frequency)))
        assert self.minfreq < frequency < self.maxfreq, errmsg
        nk = self.real_inter(frequency) + 1.0j * self.imag_inter(frequency)
        # The dielectric function is the index of refraction squared.
        return nk**2

class EpsilonDrude(AbstractEpsilon):
    """
    The EpsilonDrude class lets the user calculate the dielectric function
    of a model material using the Drude model. The Drude model has two
    parameters, the plasma frequency \omega_P and the damping \gamma. This
    model lets the user perform model calculations, giving sharp, simple peaks.
    """
    def __init__(self, omega_P, gamma):
        super(EpsilonDrude, self).__init__()
        self.omega_P = omega_P
        self.gamma = gamma
    
    def getepsilon(self, frequencyOrWavelength, micron=False):
        omega = self.getfrequency(frequencyOrWavelength, micron)
        return 1.0 - self.omega_P**2 / (omega * (omega + 1.0j * self.gamma))

class EpsilonStatic(AbstractEpsilon):
    """Placeholder for using a constant dielectric function."""
    def __init__(self, epsilon_const):
        super(EpsilonStatic, self).__init__()
        self.epsilon_const = epsilon_const
    
    def getepsilon(self, frequencyOrWavelength, micron=False):
        """Returns the constant epsilon saved in self."""
        frequency = self.getfrequency(frequencyOrWavelength, micron)
        return self.epsilon_const
        

def test():
    """Add testing of module here."""
    eps = EpsilonSOPRA('ag')
    eps.getepsilon(3.5)
    eps = EpsilonDrude(3.0, 0.3)
    eps.getepsilon(3.5)

if __name__ == '__main__':
    test()


